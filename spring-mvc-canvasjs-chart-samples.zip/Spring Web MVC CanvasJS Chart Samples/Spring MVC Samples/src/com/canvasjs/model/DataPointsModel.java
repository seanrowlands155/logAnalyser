package com.canvasjs.model;

public class DataPointsModel {
	int x,y;
	
	public void setX(int x){
		this.x=x;
	}
	
	public void setY(int y){
		this.y=y;
	}
}
